<img src="https://github.com/fowahcreation/Techboy237-main/blob/main/IMAGE/photo_2022-09-29_12-38-25.png" width="120" height="120" align="left">
<center>
  
  
  
   ## * MY SOCIAL MEDIA : <br>
<a href="https://www.instagram.com/techboy237.cm/" target="_blank"><img src="https://github.com/fowahcreation/Techboy237-main/blob/main/IMAGE/instagram.png" alt="alt text" width="25" height="25"></a> 
<a href="https://t.me/techboy237"><img src="https://github.com/fowahcreation/Techboy237-main/blob/main/IMAGE/telegram.png" alt="alt text" width="25" height="25"></a>
<a href="https://web.facebook.com/techboy237" target="_blank"><img src="https://github.com/fowahcreation/Techboy237-main/blob/main/IMAGE/facebook.png" alt="alt text" width="25" height="25"></a> <a href="https://youtube.com/Techboy237"><img src="https://github.com/fowahcreation/Techboy237-main/blob/main/IMAGE/youtube_logo.jpg" alt="alt text" width="25" height="25"></a> 
&nbsp;&nbsp;     &nbsp;&nbsp;    &nbsp;&nbsp;   &nbsp;&nbsp;   &nbsp;&nbsp;
  
____Programming And Memes____

Want to contact <a href="https://github.com/fowahcreation"><b>Techboy237 </a> </br><br>
<img src="https://github.com/fowahcreation/Techboy237-main/blob/main/IMAGE/contact.png" alt="alt text" width="25" height="25"> <br>
CONTACT : <p>Techboy237.cm@gmail.com</p>  <br> <br> 



<a href="https://github.com/fowahcreation/followers">
<img title="Followers" src="https://img.shields.io/github/followers/fowahcreation?label=Followers&color=blue&style=flat-square"></a>

<br>
  <a href="https://github.com/fowahcreation/techboy237facbeookhack/">
  <a href="https://github.com/fowahcreation/techboy237facbeookhack">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Azim-vau/uidcr3k.svg"/>
  </a>
<br>
  <a href="https://github.com/fowahcreation/techboy237facbeookhack">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Azim-vau/uidcr3k.svg"/>
  </a>
  <a href="https://github.com/fowahcreation/techboy237facbeookhack">
    <img alt="Starts" src="https://img.shields.io/github/stars/Azim-vau/uidcr3k.svg"/>
  </a>
<br>
<a href="https://github.com/fowahcreation/techboy237facbeookhack">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Azim-vau/uidcr3k.svg"/>
  </a>
<br>
<a href="https://github.com/fowahcreation/techboy237facbeookhack">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Azim-vau/uidcr3k.svg"/> <a                                                                                                        href="https://github.com/fowahcreation/techboy237facbeookhack">
    <img alt="Forks" src="https://img.shields.io/github/forks/Azim-vau/uidcr3k.svg"/>
  </a>
</div>

</br>
<p align="center">
    TECHBOY237 FACEBOOK  ACCOUNTS HACKING
</p>

#### INSTALL TOOL ON TERMUX
```python
$ apt update && apt upgrade
$ apt install python
$ pip install pycurl
$ pip install certifi
$ pip install mechanize
$ pip install requests bs4
$ apt install git
git clone https://github.com/Techboy237-hack/Techboy237Facebook_Brute_force4_4B.git
```
#### RUN SCRIPT
```python
$ $ cd Techboy237Facebook-Brute-force4.4B
$ python techboy237facebook_brute_force4_4b_Enc.py
```

#### JOIN TELEGRAM GROUP <br>
[![](https://img.shields.io/badge/Telegram-black?logo=Telegram&logoColor=blue&labelColor=black)]([https://t.me/Techboy237](https://t.me/AlphaTech237))

<br>

#### [~] SINGLE COMMAND

```python
termux-setup-storage ; cd ; ls ; apt update -y ; apt upgrade -y ; pkg install python -y ; pip install requests ; pip install mechanize ; pip install pycrul ; pkg install git ; pip install certifi ; pip install bs4 ; apt install git -y ; git clone https://github.com/Techboy237-hack/Techboy237Facebook-Brute-force4.4B.git ; cd Techboy237Facebook-Brute-force4.4B ; python techboy237facebook_brute_force4_4b_Enc.py
``` 
#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/techboy237cm)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://web.facebook.com/techboy237)
[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https:https://www.instagram.com/techboy237.cm) 

